-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 14, 2024 at 08:27 AM
-- Server version: 5.7.39
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_event`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `image` text NOT NULL,
  `description` text NOT NULL,
  `size` int(11) DEFAULT NULL,
  `type` set('wedding','birthday','baby shower','funerial','concert') DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL,
  `place` varchar(40) NOT NULL,
  `model_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `group_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `group_users`
--

CREATE TABLE `group_users` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `models`
--

CREATE TABLE `models` (
  `id` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `type` set('wedding','birthday','baby shower','funerial','concert') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `joined_at`) VALUES
(1, 'Raphaël', 'Raclot', 'raclot.raphael@gmail.com', 'azertyuiop', '2024-05-13 14:24:41'),
(2, 'Test', 'Test', 'test@test.com', '$2y$10$..mrE9thbDrmf1/qN4hiSO8Y4anSWKCoaKskXVJB9Q6/zdmxETIHq', '2024-05-13 17:21:21'),
(3, 'Alec', 'Soto', 'cigenusuq@mailinator.com', '$2y$10$pgzH0k1u.NZ.NAIzQ1v2q.ZNEC/L/xiZNiFqaYyK/ICJlF0x/ftJS', '2024-05-13 17:45:04'),
(4, 'Benoît', 'Parmentier', 'benoit.parmentier45@gmail.com', '$2y$10$aPm6WDTEK/fM8p9UMDbZ2ef9d52LkMVlijKJdPuvyo6Y2fJ00k0se', '2024-05-14 06:48:27'),
(5, 'Hermione', 'Munoz', 'nysypajy@mailinator.com', '$2y$10$4O7JAXL6gY0qkFmIj.Bbm.9kpf5PhxZzg514zxcvBgNEv3iXnLb2G', '2024-05-14 07:51:56'),
(6, 'Regina', 'Richardson', 'maku@mailinator.com', '$2y$10$.m4Lt7GbpmSOcZGCL.WjweW6Zk7wULfrwE4Sf9jhDmMfLYA1yrowq', '2024-05-14 07:55:08'),
(7, 'Kellie', 'Sanford', 'gevi@mailinator.com', '$2y$10$iMmKzT9I.CKR6tpATmeTMeyGrLBHeRMjkjV5iRgBYZ1XLmIxRcNwe', '2024-05-14 07:56:21'),
(8, 'Malik', 'Alexander', 'noxes@mailinator.com', '$2y$10$fxIVRTUngX0dA6hEOJD5bOKRBYQVMMBX8pP/bYvFXeCC.b8afMj1m', '2024-05-14 07:59:15'),
(9, 'Anthony', 'Domingues', 'anthony.domingues@gmail.com', '$2y$10$HLlv478svblQuC1MNBjIkuBpOwyjOmII4Fip.6IldkM7y2BK0mHrO', '2024-05-14 07:59:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_event_event_model_id_foreign` (`model_id`),
  ADD KEY `app_event_event_user_id_foreign` (`user_id`),
  ADD KEY `app_event_event_group_id_foreign` (`group_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_event_group_group_user_id_foreign` (`group_user_id`);

--
-- Indexes for table `group_users`
--
ALTER TABLE `group_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_event_group_user_user_id_foreign` (`user_id`),
  ADD KEY `app_event_group_user_group_id_foreign` (`group_id`);

--
-- Indexes for table `models`
--
ALTER TABLE `models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `group_users`
--
ALTER TABLE `group_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `models`
--
ALTER TABLE `models`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `app_event_event_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  ADD CONSTRAINT `app_event_event_model_id_foreign` FOREIGN KEY (`model_id`) REFERENCES `models` (`id`),
  ADD CONSTRAINT `app_event_event_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `app_event_group_group_user_id_foreign` FOREIGN KEY (`group_user_id`) REFERENCES `group_users` (`id`);

--
-- Constraints for table `group_users`
--
ALTER TABLE `group_users`
  ADD CONSTRAINT `app_event_group_user_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  ADD CONSTRAINT `app_event_group_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
